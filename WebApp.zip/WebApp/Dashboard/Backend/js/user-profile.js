//let token;
let token;

document.addEventListener('DOMContentLoaded', async () => {
    try {
        token = localStorage.getItem('authToken');
  
        if (!token) {
            console.error('Token not found. Please log in.');
            // Redirect to login or handle as needed
            window.location.href = 'http://100.101.103.1/Dashboard/Frontend/login.html';
            return;
        }
       
        // Fetch user information or role from the server
        const response = await fetch('http://100.101.103.1:3000/profile', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
        });
       
        if (response.ok) {
            const userData = await response.json();
       
            // Check if the user is an admin
            if (userData.userRole !== 0) {
                // Redirect non-admin users to the regular profile page
                window.location.href = 'http://100.101.103.1/Dashboard/Frontend/login.html';
                return;
            }
        } else {
            console.error('Error fetching user information:', response.status, response.statusText);
            alert('Error fetching user information. Please try again.');
       
            window.location.href = 'http://100.101.103.1/Dashboard/Frontend/login.html';
        }
      
    } catch (error) {
        console.error('Error during initialization:', error.message);
    }
});        

document.getElementById('logoutBtn').addEventListener('click', async () => {
    try {
        const response = await fetch('http://100.101.103.1:3000/logout', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
        });
   
        if (response.ok) {
            // Logout successful
            console.log('Logout successful');
            window.location.href = 'http://100.101.103.1/Dashboard/Frontend/login.html';
        } else {
            // Logout failed
            console.error('Logout failed:', response.status, response.statusText);
        }
    } catch (error) {
         console.error('Error during logout:', error);
    }
});

document.addEventListener('DOMContentLoaded', async () => {
    try {
	token = localStorage.getItem('authToken');

        if (!token) {
	    console.error('Token not found. Please log in.');
            window.location.href = 'http://100.101.103.1/Dashboard/Frontend/login.html';
            return;
        }        

        // Fetch user data
        const userData = await fetchUserData();


        // Update profile HTML
        updateProfile(userData);


    } catch (error) {
        console.error('Error fetching user profile:', error.message);
    }
});

async function fetchUserData() {
    try {
        const response = await fetch('http://100.101.103.1:3000/profile', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
        });

        if (!response.ok) {
            throw new Error('Failed to fetch user data');
        }

        const userData = await response.json();
        //console.log('User data:', userData);
        return userData;
    } catch (error) {
        console.error('Failed to fetch user data:', error);
        window.location.href = 'http://100.101.103.1/Dashboard/Frontend/login.html';
    }
}

function updateProfile(userData) {
    
    if (!userData) {
        console.error('User data is missing.');
        return;
    }

    const nameElement = document.getElementById('name');
    const lastnameElement = document.getElementById('lastname');
    const usernameElement = document.getElementById('username');

    nameElement.value = userData.name;
    lastnameElement.value = userData.lastname;
    usernameElement.value = userData.username;

    // Show the "Edit" button
    document.getElementById('editButton').style.display = 'block';

    // Hide the "Save Changes" button
    document.getElementById('saveChangesButton').style.display = 'none';
}

function enableEditing() {
    // Enable editing for all readonly inputs
    document.querySelectorAll('input[readonly]').forEach(input => {
        input.removeAttribute('readonly');
    });

    // Enable editing for all disabled inputs (added this part)
    document.querySelectorAll('input[disabled]').forEach(input => {
        input.removeAttribute('disabled');
    });

    // Hide the "Edit" button
    document.getElementById('editButton').style.display = 'none';

    // Show the "Save Changes" button
    document.getElementById('saveChangesButton').style.display = 'block';
}

async function saveChanges(event) {
    event.preventDefault();

    const formData = new FormData(event.target);

    const updatedUserData = {};
    formData.forEach((value, key) => {
        updatedUserData[key] = value;
    });

    try {
        const response = await fetch('http://100.101.103.1:3000/profile/update', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
            body: JSON.stringify(updatedUserData),
        });

        const responseData = await response.json();

        if (!response.ok) {
            if (responseData.error === "Username already exists. Please choose a different one.") {
                // Handle the case where the username already exists
                alert("Username already exists. Please choose a different one.");
            } else {
                // If response is not OK and the error is not related to username already existing, handle it as a general error
                throw new Error(responseData.error || 'Failed to update profile');
            }
        } else {
            // Update profile HTML
            updateProfile(responseData);

            // Disable editing and show "Edit" button
            disableEditing();

            // Disable form fields immediately after saving changes
            disableFormFields();
        }
    } catch (error) {
        console.error('Error updating profile:', error.message);
        // Display error message to the user
        alert(error.message);
    }
}

function disableFormFields() {
    // Disable all form fields
    document.querySelectorAll('form input').forEach(input => {
        input.setAttribute('disabled', true);
    });
}

function disableEditing() {
    // Disable editing for all readonly inputs
    document.querySelectorAll('input[readonly]').forEach(input => {
        input.setAttribute('readonly', true);
    });

    // Show the "Edit" button
    document.getElementById('editButton').style.display = 'block';

    // Hide the "Save Changes" button
    document.getElementById('saveChangesButton').style.display = 'none';
}

function logout() {
    // Perform any additional cleanup or requests if needed

    fetch('http://100.101.103.1:3000/logout', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
        },
    })
    .then(response => {
        if (response.ok) {
            // Logout successful, redirect to the login page
            window.location.href = 'http://100.101.103.1/Dashboard/Frontend/login.html';
        } else {
            // Handle error, display a message, etc.
            console.error('Logout failed:', response.statusText);
        }
    })
    .catch(error => {
        // Handle network or other errors
        console.error('Logout failed:', error.message);
    });
}

// Move event listeners outside of functions
document.getElementById('editButton').addEventListener('click', enableEditing);
document.getElementById('editProfileForm').addEventListener('submit', saveChanges);
document.getElementById('saveChangesButton').addEventListener('click', disableEditing);