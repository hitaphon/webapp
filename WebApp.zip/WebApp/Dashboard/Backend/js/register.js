$(document).ready(function () {
    $("#registerButton").click(async function (event) {
        event.preventDefault();

        // Basic form validation
        var firstName = $("#exampleFirstName").val();
        var lastName = $("#exampleLastName").val();
        var username = $("#exampleUsername").val();
        var password = $("#exampleInputPassword").val();
        var repeatPassword = $("#exampleRepeatPassword").val();

        if (firstName === '' || lastName === '' || username === '' || password === '' || repeatPassword === '') {
            alert("All fields must be filled out");
            return;
        }

        if (password !== repeatPassword) {
            alert("Passwords do not match");
            return;
        }

        try {
            // Send data to the server
            const response = await fetch('http://100.101.103.1:3000/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    User_name: firstName,
                    User_lastname: lastName,
                    User_username: username,
                    User_password: password,
                    User_role: '0',
                }),
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Registration failed.');
            }

            // Handle success, e.g., redirect to login page
            window.location.href = "login.html";
        } catch (error) {
            // Handle error, e.g., show an alert
            alert(`Registration failed: ${error.message}`);
        }
    });
});
