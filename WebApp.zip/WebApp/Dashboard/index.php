<?php
	header("Location: .\Frontend\login.html");
	exit;