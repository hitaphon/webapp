const jwt = require('jsonwebtoken');

const JWT_SECRET = 'H6mxZFdjYecMCzWRUsjvwDcgukfg15Jji0iymHnQb6w=';


function verifyToken(req, res, next) {
    const token = req.headers['authorization'] ? req.headers['authorization'].split(' ')[1] : null;

    console.log('Received Token:', token);

    jwt.verify(token, JWT_SECRET, (err, decodedToken) => {
        if (err) {
            console.error('Error verifying JWT token:', err);
            return res.status(401).json({ error: 'Unauthorized' });
        }

        console.log('Decoded Token:', decodedToken);

        // Attach the decoded token to the request object
        req.decodedToken = decodedToken;

        // Continue to the next middleware or route handler
        next();
    });
}

module.exports = { verifyToken };