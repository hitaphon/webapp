const express = require('express');
const cors = require('cors');
const fileUpload = require('express-fileupload');
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = 'H6mxZFdjYecMCzWRUsjvwDcgukfg15Jji0iymHnQb6w=';

app.use(cors());
app.use(express.json());
app.use(fileUpload());
app.use(express.urlencoded({ extended: true }));

let pool;
const activeSessions = new Map();

async function connectToDatabase() {
    try {
        if (!pool) {
            pool = await mysql.createPool({
                host: '10.62.0.183',
                port: 3306,
                user: 'mysql3',
                password: 'P@55vv0rd',
                database: 'DashboardDB',
                waitForConnections: true,
                connectionLimit: 10,
                queueLimit: 0,
                Promise: Promise,
            });

            console.log('Connected to MySQL database');
        }

        return pool;
    } catch (error) {
        console.error('Error connecting to MySQL:', error);
        throw error;
    }
}

const blacklistedTokens = [];

function isAuthenticated(req, res, next) {
    // Get the token from the request headers
    const token = req.headers['authorization'] ? req.headers['authorization'].split(' ')[1] : null;

    if (!token) {
        // No token provided, user is not authenticated
        return res.redirect('http://100.101.103.1/Dashboard/Frontend/login.html');
    }

    try {
        // Check if the token is in the blacklist
        if (blacklistedTokens.includes(token)) {
            return res.redirect('http://100.101.103.1/Dashboard/Frontend/login.html');
        }

        // Verify the token
        const decodedToken = jwt.verify(token, JWT_SECRET);

        // Check if the user exists in the active sessions
        if (activeSessions.has(decodedToken.username)) {
            // User is authenticated, continue to the next middleware or route
            return next();
        } else {
            // User is not authenticated, redirect to login page
            return res.redirect('http://100.101.103.1/Dashboard/Frontend/login.html');
        }
    } catch (error) {
        // Token is invalid, user is not authenticated
        console.error('Invalid token:', error);
        return res.redirect('http://100.101.103.1/Dashboard/Frontend/login.html');
    }
}

app.post('/register', async (req, res) => {
    try {
        console.log('Received registration request:', req.body);
        const dbPool = await connectToDatabase(); // Ensure to call the function to get the pool

        if (!dbPool) {
            console.error('Database pool is undefined.');
            return res.status(500).json({ error: 'Error during registration. Please try again.' });
        }

        const userData = req.body;

        // Check if the user with the same username already exists
        const [existingUser] = await dbPool.execute('SELECT User_username FROM users WHERE User_username = ?', [userData.User_username]);

        if (existingUser.length > 0) {
            return res.status(400).json({ error: 'User with this username already exists.' });
        }

        if (!userData.User_password) {
            return res.status(400).json({ error: 'Password is required.' });
        }

        const hashedPassword = await bcrypt.hash(userData.User_password, 10);

        const result = await dbPool.execute(
            'INSERT INTO users (User_name, User_lastname, User_username, User_password) VALUES (?, ?, ?, ?)',
            [userData.User_name, userData.User_lastname, userData.User_username, hashedPassword]
        );

        console.log('Database Insert Result:', {
            insertedUser: {
                User_name: userData.User_name,
                User_lastname: userData.User_lastname,
                User_username: userData.User_username,
                User_password: '********',
                User_role: userData.User_role,
            },
            affectedRows: result[0].affectedRows,
            insertId: result[0].insertId,
            message: 'Registration successful!',
        });

        res.status(200).json({ message: 'Registration successful!' });
    } catch (error) {
        console.error('Error during registration:', error);

        if (error.code) {
            console.error('MySQL Error:', error.code);
        }

        res.status(500).json({ error: 'Error during registration. Please try again.' });
    }
});

app.post('/login', async (req, res) => {
    try {
        console.log('Received login request:', req.body);
        const dbPool = await connectToDatabase();
        const userData = req.body;

        const [user] = await dbPool.execute('SELECT * FROM users WHERE User_username = ?', [userData.User_username || null]);

        //console.log('User data:', user[0]);

        if (!user || user.length === 0) {
            return res.status(401).json({ error: 'User not found.' });
        }

        const passwordMatch = await bcrypt.compare(userData.User_password, user[0].User_password);

        if (!passwordMatch) {
            return res.status(401).json({ error: 'Incorrect password.' });
        }

        // Generate and send the token in the response
        const token = jwt.sign(
            {
                userId: user[0].User_id,  
                username: user[0].User_username,
                userRole: user[0].User_role,
            },
            JWT_SECRET,
            //{ expiresIn: '1h' }
        );

        // Store the session
        activeSessions.set(user[0].User_username, token);

        res.status(200).json({ token, userId: user[0].User_id, userRole: user[0].User_role });

    } catch (error) {
        console.error('Error during login:', error);

        if (error[0] && error[0].errno) {
            console.error('MySQL Error:', error[0].message);
        }

        res.status(500).json({ error: 'Error during login. Please try again.' });
    }
});

app.get('/profile', isAuthenticated, async (req, res) => {
    try {
        console.log('Received profile request headers:', req.headers);

        const dbPool = await connectToDatabase();

        // Decode and log the token
        const token = req.headers['authorization'].split(' ')[1];
        //console.log('Received profile request with token:', token);

        // Verify the token
        const decodedToken = jwt.verify(token, JWT_SECRET);
        //console.log('Decoded Token:', decodedToken);

        // Use the correct column names when fetching user data
        const [user] = await dbPool.execute('SELECT * FROM users WHERE User_username = ?', [decodedToken.username]);

        if (user.length === 0) {
            return res.status(404).json({ error: 'User not found.' });
        }

        // Send the user data as a response
        res.status(200).json({
            name: user[0].User_name,
            lastname: user[0].User_lastname,
            username: user[0].User_username,
            userRole: user[0].User_role,
        });
    } catch (error) {
        console.error('Error handling profile request:', error);
        res.status(500).json({ error: 'Error handling profile request. Please try again.' });
    }
});

app.post('/profile/update', isAuthenticated, async (req, res) => {
    try {
        const dbPool = await connectToDatabase();

        const token = req.headers['authorization'].split(' ')[1];
        const decodedToken = jwt.verify(token, JWT_SECRET);
        const userId = decodedToken.userId; 

        const updatedData = req.body;

        if (!userId) {
            return res.status(400).json({ error: 'User ID is missing.' });
        }

        // Check if the updated username already exists
        const [existingUser] = await dbPool.execute('SELECT User_username FROM users WHERE User_username = ? AND User_id != ?', [updatedData.username, userId]);

        if (existingUser.length > 0) {
            res.status(400).json({ error: 'Username already exists. Please choose a different one.' });
            return;
        }

        // Use the correct column names when updating user data
        const result = await dbPool.execute(
            'UPDATE users SET User_name = ?, User_lastname = ?, User_username = ? WHERE User_id = ?',
            [updatedData.name, updatedData.lastname, updatedData.username, userId]
        );

        console.log('Database Update Result:', {
            affectedRows: result[0].affectedRows,
            message: 'Profile updated successfully!',
        });

        // Fetch the updated profile data
        const [updatedProfile] = await dbPool.execute('SELECT * FROM users WHERE User_id = ?', [userId]);

        res.status(200).json({
            userId: updatedProfile[0].User_id,
            name: updatedProfile[0].User_name,
            lastname: updatedProfile[0].User_lastname,
            username: updatedProfile[0].User_username,
        });
    } catch (error) {
        console.error('Error updating user profile:', error);

        if (error.code) {
            console.error('MySQL Error:', error.code);
        }

        res.status(500).json({ error: 'Error updating user profile. Please try again.' });
    }
});


app.post('/update-password', isAuthenticated, async (req, res) => {
    try {
        const dbPool = await connectToDatabase();

        // Decode and verify the token
        const decodedToken = jwt.verify(req.headers['authorization'].split(' ')[1], JWT_SECRET);
        const userId = decodedToken.userId; 

        const { userId: bodyUserId, newPassword } = req.body; 

        console.log('Received userId from body:', bodyUserId);
        console.log('Received newPassword:', newPassword);

        // if (!bodyUserId || bodyUserId !== userId) {
        //     return res.status(400).json({ error: 'Invalid userId provided.' });
        // }

        const hashedPassword = await bcrypt.hash(newPassword, 10);

        // Use the correct column names when updating the password
        const result = await dbPool.execute(
            'UPDATE users SET User_password = ? WHERE User_id = ?',
            [hashedPassword, bodyUserId]
        );

        console.log('Password Update Result:', {
            newPassword,
            hashedPassword,
            affectedRows: result[0].affectedRows,
            message: 'Password updated successfully!',
        });

        res.status(200).json({ message: 'Password updated successfully!' });
    } catch (error) {
        console.error('Error updating password:', error);

        if (error.code) {
            console.error('MySQL Error:', error.code);
        }

        res.status(500).json({ error: 'Error updating password. Please try again.' });
    }
});

app.post('/file-upload', isAuthenticated, (req, res) => {
    try {
        if (!req.files || Object.keys(req.files).length === 0) {
            return res.status(400).json({ error: 'No files were uploaded.' });
        }

        const uploadedFile = req.files.fileToUpload;
        const uploadPath = path.join(__dirname, 'uploads', uploadedFile.name);

        uploadedFile.mv(uploadPath, (err) => {
            if (err) {
                console.error('Error uploading file:', err);
                return res.status(500).json({ error: 'Error uploading file.' });
            }

            console.log('File uploaded successfully!');
            res.status(200).json({ imageUrl: `/uploads/${uploadedFile.name}` });
        });
    } catch (error) {
        console.error('Error handling file upload:', error);
        res.status(500).json({ error: 'Error handling file upload. Please try again.' });
    }
});

app.post('/logout', async (req, res) => {
    try {
        const token = req.headers['authorization'].split(' ')[1];
        const decodedToken = jwt.verify(token, JWT_SECRET);

        // Add the token to a blacklist or remove it from active sessions
        blacklistedTokens.push(token);

        // Clear the token from client-side storage
        res.clearCookie('authToken');

        res.status(200).json({ message: 'Logout successful.' });
    } catch (error) {
        console.error('Error during logout:', error);
        res.status(500).json({ error: 'Error during logout. Please try again.' });
    }
});

process.on('beforeExit', async () => {
    try {
        if (pool) {
            await pool.end();
            console.log('Closed MySQL database connection pool');
        }
    } catch (error) {
        console.error('Error closing database connection pool:', error);
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});