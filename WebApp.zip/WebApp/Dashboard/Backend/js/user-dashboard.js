let token;

document.addEventListener('DOMContentLoaded', async () => {
    try {
        token = localStorage.getItem('authToken');

        if (!token) {
            console.error('Token not found. Please log in.');
            // Redirect to login or handle as needed
            window.location.href = 'http://100.101.103.1/Dashboard/Frontend/login.html';
            return;
        }

        // Fetch user information or role from the server
        const response = await fetch('http://100.101.103.1:3000/profile', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
        });

        if (response.ok) {
            const userData = await response.json();
            
            // Check if the user is an admin
            if (userData.userRole !== 0) {
                //alert('Access denied.');
                
                window.location.href = 'http://100.101.103.1/Dashboard/Frontend/login.html';
            }
        } else {
            console.error('Error fetching user information:', response.status, response.statusText);
            alert('Error fetching user information. Please try again.');

            window.location.href = 'http://100.101.103.1/Dashboard/Frontend/login.html';
        }
        
    } catch (error) {
        console.error('Error during initialization:', error.message);
    }
});

document.getElementById('logoutBtn').addEventListener('click', async () => {
    try {
        // Perform logout actions here using the 'token' variable
        console.log('Logout button clicked');
        const response = await fetch('http://100.101.103.1:3000/logout', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`, 
            },
        });

        if (response.ok) {
            // Logout successful
            console.log('Logout successful');

            // Remove the token from local storage
            localStorage.removeItem('authToken');
            //console.log("Token:", authToken);
            // Redirect to login page
            window.location.href = 'http://100.101.103.1/Dashboard/Frontend/login.html';
        } else {
            // Logout failed
            console.error('Logout failed:', response.status, response.statusText);
        }
    } catch (error) {
        console.error('Error during logout:', error);
    }
});