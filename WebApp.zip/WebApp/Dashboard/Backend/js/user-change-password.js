let token;

document.addEventListener('DOMContentLoaded', async () => {
    try {
        token = localStorage.getItem('authToken');
        
        if (!token) {
            console.error('Token not found. Please log in.');
            // Redirect to login or handle as needed
            window.location.href = 'http://100.101.103.1/Dashboard/Frontend/login.html';
            return;
        }
        
        // Fetch user information or role from the server
        const response = await fetch('http://100.101.103.1:3000/profile', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
        });
        
        if (response.ok) {
            const userData = await response.json();
        
        } else {
            console.error('Error fetching user information:', response.status, response.statusText);
            alert('Error fetching user information. Please try again.');
        
            window.location.href = 'http://100.101.103.1/Dashboard/Frontend/login.html';
        }
                
    } catch (error) {
        console.error('Error during initialization:', error.message);
    }
});

document.getElementById('logoutBtn').addEventListener('click', async () => {
    try {
        const response = await fetch('http://100.101.103.1:3000/logout', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`, 
            },
        });
    
        if (response.ok) {
            // Logout successful
            console.log('Logout successful');
            localStorage.removeItem('authToken');
            window.location.href = 'http://100.101.103.1/Dashboard/Frontend/login.html';
        } else {
            // Logout failed
            console.error('Logout failed:', response.status, response.statusText);
        }
    } catch (error) {
        console.error('Error during logout:', error);
    }
});

async function changePassword() {
    try {
        // Retrieve values from input fields
        const newPassword = document.getElementById('newPassword').value;
        const confirmNewPassword = document.getElementById('confirmNewPassword').value;

        const userId = localStorage.getItem('userId');
        const userRole = localStorage.getItem('userRole');


        if (!token) {
            console.error('Token not found. Please log in.');
            return;
        }

        if (!newPassword || newPassword !== confirmNewPassword) {
            console.error('New password and confirm password do not match.');
            return;
        }

        if (!newPassword) {
            console.error('New password is required.');
            return;
        }

        if (!userId || !userRole) {
            console.error('User Id or User Role not found. Please log in.');
            return;
        }
        
        const apiUrl = 'http://100.101.103.1:3000/update-password';

        //console.log('userId', userId);
        //console.log('userRole', userRole);

        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
            body: JSON.stringify({
                userId,
                //userRole,
                newPassword,
            }),
        });

        if (!response.ok) {
            throw new Error(`Failed to update password: ${response.statusText}`);
        }

        // Password update successful
        const result = await response.json();
        console.log('Password update result:', result);

        // Show alert
        alert('Password updated successfully!');

        // Clear input fields
        document.getElementById('currentPassword').value = '';
        document.getElementById('newPassword').value = '';
        document.getElementById('confirmNewPassword').value = '';

    } catch (error) {
        console.error('Error changing password:', error.message);
    }
}

function cancelChange() {
    console.log('Change password operation canceled.');
}

function logout() {
    // Perform any additional cleanup or requests if needed

    fetch('http://100.101.103.1:3000/logout', { 
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
        },
    })
    .then(response => {
        if (response.ok) {
            // Logout successful, redirect to the login page
            localStorage.removeItem('authToken');
            window.location.href = 'http://100.101.103.1/Dashboard/Frontend/login.html';
        } else {
            // Handle error, display a message, etc.
            console.error('Logout failed:', response.statusText);
        }
    })
    .catch(error => {
        // Handle network or other errors
        console.error('Logout failed:', error.message);
    });
}
