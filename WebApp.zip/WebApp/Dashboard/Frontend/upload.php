<?php
$target_dir = $_SERVER['DOCUMENT_ROOT'] . "/Dashboard/Frontend/uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

$uploaded_name = $_FILES[ 'fileToUpload' ][ 'name' ];
$uploaded_type = $_FILES[ 'fileToUpload' ][ 'type' ];
$uploaded_size = $_FILES[ 'fileToUpload' ][ 'size' ];

echo $uploaded_name;
echo $uploaded_type;
echo $uploaded_size;

if(( $uploaded_type == "image/jpeg" || $uploaded_type == "image/png" ) && ( $uploaded_size < 100000 )) {
    if( !move_uploaded_file( $_FILES[ 'fileToUpload' ][ 'tmp_name' ], $target_file) ){
        echo '<pre>Your image was not uploaded.</pre>';
    }
    else{
        echo 'Uploads file to Dashboard/Frontend/uploads successfully uploaded!</pre>';
    }
}
else{
    echo '<pre>Your image was not uploaded. We can only accept JPEG or PNG images.</pre>';
}

?>