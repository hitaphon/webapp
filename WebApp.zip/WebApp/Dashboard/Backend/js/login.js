$(document).ready(function () {
    $("#loginButton").click(async function (event) {
        event.preventDefault();

        var username = $("#exampleUsername").val();
        var password = $("#exampleInputPassword").val();

        if (username === '' || password === '') {
            alert("Please fill in both username and password.");
            return;
        }

        try {
            // Send login data to the server
            const response = await fetch('http://100.101.103.1:3000/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    User_username: username,
                    User_password: password,
                }),
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Login failed.');
            }

            // Retrieve user information and token from the server response
            const responseData = await response.json();

            const token = responseData.token;
            const userId = responseData.userId;
            const userRole = responseData.userRole;

            localStorage.setItem('authToken', token);
            localStorage.setItem('userId', userId);
            localStorage.setItem('userRole', userRole);

            // Store the token in session storage
            sessionStorage.setItem('authToken', token);
            sessionStorage.setItem('userId', userId);
            sessionStorage.setItem('userRole', userRole);

            // Wait for the storage operation to finish
            await new Promise(resolve => setTimeout(resolve, 100));

            // Check user role and redirect accordingly
            const storedUserRole = localStorage.getItem('userRole');
            if (storedUserRole == 1) {
                console.log("userRole:", storedUserRole);
                console.log("Before redirection, userRole =", storedUserRole);
                console.log("Redirecting to profile.html");
                window.location.href = 'dashboard.html';
            } else if (storedUserRole == 0) {
                console.log("userRole:", storedUserRole);
                console.log("Before redirection, userRole =", storedUserRole);
                console.log("Redirecting to user-profile.html");
                window.location.href = 'user-dashboard.html';
            }

        } catch (error) {
            // Handle error, e.g., show an alert
            alert(`Login failed: ${error.message}`);
        }
    });
});
