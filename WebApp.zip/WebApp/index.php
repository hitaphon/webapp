<?php
	header("Location: Dashboard\Frontend\login.html");
	exit;